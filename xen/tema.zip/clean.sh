#!/bin/bash

rm receiver sender load iterations
