#!/bin/bash

./clean.sh
git add .
git commit -m "new stuff"
git push
